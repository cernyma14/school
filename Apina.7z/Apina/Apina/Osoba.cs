﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apina
{
    public class Osoba
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string RC1 { get; set; }
        public string RC2 { get; set; }
        public DateTime BirthDate { get; set; }
        public string Pohlavi { get; set; }

        public int Age
        {
            get { return _age(); }
        }
        public int _age()
        {
            DateTime now = DateTime.Today;
            int age = now.Year - BirthDate.Year;
            if (now < BirthDate.AddYears(age)) age--;
            return age;
        }

        public override string ToString()
        {
            return "Příjmení: " + Surname + " Jméno: " + Name + " RČ: " + RC1 + "/" + RC2 + " vek: " + Age + " datum: " + BirthDate;
        }
    }
}
